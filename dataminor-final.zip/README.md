# data_minor
data mining group classification project
